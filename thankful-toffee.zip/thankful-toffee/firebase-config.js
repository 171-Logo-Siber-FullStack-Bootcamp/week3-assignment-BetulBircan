// Import the functions you need from the SDKs you need
import * as firebase from 'firebase';
import 'firebase/firebase-app';

import 'firebase/firestore';
import 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB9HHTHJ96WAynUhCQPGgBPKv4_oZ5Lbvk",
  authDomain: "react-332518.firebaseapp.com",
  projectId: "react-332518",
  storageBucket: "react-332518.appspot.com",
  messagingSenderId: "756887778806",
  appId: "1:756887778806:web:d04bdb828f39fd243ac3d7",
  measurementId: "G-DVHRE3X1HB"
};

// let app;
// if(firebase.app.length === 0) {
//   app=firebase.initializeApp(firebaseConfig)
// } else {
//   app=firebase.app()
// }

// const fireStore = firebase.firestore();
// const auth = firebase.auth()
// export {firebase,auth}