// import * as React from 'react';
import React, { Component } from 'react';
import { Text, View, StyleSheet, TextInput, Dimensions } from 'react-native';
import Constants from 'expo-constants';
import {StatusBar} from 'expo-status-bar'
import Svg, { Path, Circle } from "react-native-svg"
const {width, height}=Dimensions.get('window')
import ButtonGradient from '../ButtonGradient'


//import * as Svg from 'react-native-svg';

// You can import from local files


// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
export default class LoginScreen extends Component { 
   myDeger = "deneme";

  constructor(props) {
    super(props)

    console.log("Merhaba")
    this.state={
      userName:"",
      password:""
    }
  }

   styles = StyleSheet.create({
    mainContainer: {
    backgroundColor: '#f1f1f1',
    flex:1,

  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',

  },
  containerSVG: {
   width: width,
   justifyContent:"flex-start",
   alignItems: 'center'
  },
  titulo: {
    fontSize: 80,
    color: '#34434D',
    fontWeight: 'bold',
  },
  subTitle: {
    fontSize: 20,
    color:'gray'
  },
  textInput: {
    padding: 10,
    paddingStart: 30,
    width: '80%',
    height: 50,
    marginTop: 20,
    borderRadius:30,
    backgroundColor: '#fff'
  },
  forgotPassword: {
    fontSize:14,
    color:'gray',
    marginTop:20
  },
  button: {
    width: '80%',
    height: 50,
  },
  
});

 loginHandler = () => {

    auth.signInWithEmailAndPassword(this.state.userName, this.state.password).then((uc)=>{
      if(uc.user) {
        this.route.navigaiton.navigate("MainScreen")
      }
      else {
        console.log("Kullanıcı bulunamadı")
      }
    }).catch(error =>{
      console.log(error)
    })

    
  }

  registerHandler = () => {
    auth
    .createUserWithEmailAndPassword(this.state.userName, this.state.password).then((uc) => {
      if(uc.user) {
        //Geçiş Yap
        this.props.navigaiton.navigate("MainScreen")
      }
      else {
        console.log("Kullanıcı Yaratılamadı")
      }
    }).catch(error => {
      console.log(error)
    })
    

    auth.signOut().then(()=>{}).catch(error=>{})
  }

 
 function SvgComponent() {
   return (
     <Svg
    className="instagram-logo"
    xmlns="http://www.w3.org/2000/svg"
    width={100}
    height={100}
    viewBox="0 0 551.034 551.034"
    style={{
      enableBackground: "new 0 0 551.034 551.034",
    }}
    xmlSpace="preserve"
    
  >
    <Path
      className="logo"
      d="M386.878 0H164.156C73.64 0 0 73.64 0 164.156v222.722c0 90.516 73.64 164.156 164.156 164.156h222.722c90.516 0 164.156-73.64 164.156-164.156V164.156C551.033 73.64 477.393 0 386.878 0zM495.6 386.878c0 60.045-48.677 108.722-108.722 108.722H164.156c-60.045 0-108.722-48.677-108.722-108.722V164.156c0-60.046 48.677-108.722 108.722-108.722h222.722c60.045 0 108.722 48.676 108.722 108.722v222.722z"
    />
    <Path
      fill="#555"
      d="M275.517 133C196.933 133 133 196.933 133 275.516s63.933 142.517 142.517 142.517S418.034 354.1 418.034 275.516 354.101 133 275.517 133zm0 229.6c-48.095 0-87.083-38.988-87.083-87.083s38.989-87.083 87.083-87.083c48.095 0 87.083 38.988 87.083 87.083 0 48.094-38.989 87.083-87.083 87.083z"
    />
    <Circle fill="#555" cx={418.306} cy={134.072} r={34.149} />
  </Svg>
   )
 }
 render () {

  return (
    <View style={styles.mainContainer}>
      <View style={styles.containerSVG}>
        <SvgComponent/>
      </View>
        <View style={this.styles.container}>
          <Text style={this.styles.titulo}>Hello</Text>
          <Text style={this.styles.subTitle}>Sign In To Your Account</Text>
          <TextInput
          style={styles.textInput}
          placeholder="mail@mail.com"
          value={this.state.userName}
          onChangeText={(text) => {
          this.setState({
            userName:text
          })
          />
          <TextInput
          style={this.styles.textInput}
          placeholder="Password" 
          value={this.state.password}
          onChangeText= { (text) => {
          this.setState({
            password:text
          })
        }
          />
          <Text style={styles.forgotPassword}>Forgot Your Password</Text>
          <ButtonGradient style={styles.button}/>
          <StatusBar style="auto" />
        </View>
    </View>
  );
}
}

